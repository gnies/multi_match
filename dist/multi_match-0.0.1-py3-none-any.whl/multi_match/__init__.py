"""
Package to match points

Examples
--------

>>> print(will come soon)

Reference
--------
None so far
"""

__version__ = "0.0.1"

# funcitons to expose:
from .matching_classes import Multi_Matching, Multi_Matching_Over_Range
from .point_detection import point_detection
